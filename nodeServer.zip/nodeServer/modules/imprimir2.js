function imprimir2() {
    for (let i = 0; i < 10; i++) {
      console.log("Node.js es muy chulo");
    }
  }

  module.exports = imprimir2;