const imprimir = require('./imprimir2');
const imprimirPesado = require('./imprimirPesado');
const infoProceso = require('./infoProceso');
const muestraContenido = require('./muestraContenido');

muestraContenido();

imprimir();

imprimirPesado();

infoProceso();