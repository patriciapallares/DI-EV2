function imprimirPesado() {
    setInterval(() => {
        console.log("Soy un pesado que se ejecuta cada 2 segundos");
      }, 2000);
  }

  module.exports = imprimirPesado;



